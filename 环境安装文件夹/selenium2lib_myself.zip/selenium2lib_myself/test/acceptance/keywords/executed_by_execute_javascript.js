window.add_content('button_target', 'Inserted via file')
